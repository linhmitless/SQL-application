 
<html>

	<p>
	First Name:<br>
	<input type="text" name="firstName">
	<br>
	Last Name:<br>
	<input type="text" name="lastName">
	<br>
	Middle Initial:<br>
	<input type="text" name="middleInitial">
	<br>
	Preferred Name:<br>
	<input type="text" name="preferredName">
	<br>
	Date of Birth<br>
	<input type="text" name="dateofBirth">
	<br>
	Mailing Address<br>
	<input type="text" name="mailingAddress">
	<br>
	Preferred Phone Number<br>
	<input type="text" name="preferredPhoneNumber">
	<br> </p>

</html>
